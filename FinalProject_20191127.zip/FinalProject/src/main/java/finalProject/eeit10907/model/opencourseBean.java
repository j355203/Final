package finalProject.eeit10907.model;

public class opencourseBean {
	private static final long serialVersionUID=1L;
	private String subjectname_a1;
	private String subjectscore_a1;
	private String subjectname_a2;
	private String coursename_a1;
	private int coursecredits_a1;
	private String starttime_a1;
	private String endtime_a1;
	private int courseroom_a1;
	private String url_a1;
	private String coursesummary_a1;
	
	
	public String getSubjectname_a1() {
		return subjectname_a1;
	}
	public void setSubjectname_a1(String subjectname_a1) {
		this.subjectname_a1 = subjectname_a1;
	}
	public String getSubjectscore_a1() {
		return subjectscore_a1;
	}
	public void setSubjectscore_a1(String subjectscore_a1) {
		this.subjectscore_a1 = subjectscore_a1;
	}
	public String getSubjectname_a2() {
		return subjectname_a2;
	}
	public void setSubjectname_a2(String subjectname_a2) {
		this.subjectname_a2 = subjectname_a2;
	}
	public String getCoursename_a1() {
		return coursename_a1;
	}
	public void setCoursename_a1(String coursename_a1) {
		this.coursename_a1 = coursename_a1;
	}
	public int getCoursecredits_a1() {
		return coursecredits_a1;
	}
	public void setCoursecredits_a1(int coursecredits_a1) {
		this.coursecredits_a1 = coursecredits_a1;
	}
	public String getStarttime_a1() {
		return starttime_a1;
	}
	public void setStarttime_a1(String starttime_a1) {
		this.starttime_a1 = starttime_a1;
	}
	public String getEndtime_a1() {
		return endtime_a1;
	}
	public void setEndtime_a1(String endtime_a1) {
		this.endtime_a1 = endtime_a1;
	}
	public int getCourseroom_a1() {
		return courseroom_a1;
	}
	public void setCourseroom_a1(int courseroom_a1) {
		this.courseroom_a1 = courseroom_a1;
	}
	public String getUrl_a1() {
		return url_a1;
	}
	public void setUrl_a1(String url_a1) {
		this.url_a1 = url_a1;
	}
	public String getCoursesummary_a1() {
		return coursesummary_a1;
	}
	public void setCoursesummary_a1(String coursesummary_a1) {
		this.coursesummary_a1 = coursesummary_a1;
	}

	
}
