package finalProject.eeit10919.dao;

import java.util.List;

import finalProject.eeit10919.model.MapInfoBean;

public interface FoodMapDao {
	public List<MapInfoBean> getAllFoodMapStore();
}
