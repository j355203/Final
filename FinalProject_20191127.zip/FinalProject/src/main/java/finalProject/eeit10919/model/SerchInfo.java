package finalProject.eeit10919.model;

public class SerchInfo {
	private int serchType;
	private String serchText;

	public int getSerchType() {
		return serchType;
	}

	public void setSerchType(int serchType) {
		this.serchType = serchType;
	}

	public String getSerchText() {
		return serchText;
	}

	public void setSerchText(String serchText) {
		this.serchText = serchText;
	}

}
