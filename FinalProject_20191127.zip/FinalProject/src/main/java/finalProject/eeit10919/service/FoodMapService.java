package finalProject.eeit10919.service;

import java.util.List;

import finalProject.eeit10919.model.MapInfoBean;

public interface FoodMapService {
	public List<MapInfoBean> getAllFoodMapStore();
}
